package layout.indocars

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
